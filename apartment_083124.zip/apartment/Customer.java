import java.util.Scanner;
class Customer extends Payment {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Customer Name");
        String customer_name=sc.nextLine();
        System.out.println("Enter Customer Nationality");
        String customer_natinality=sc.nextLine();
        System.out.println("Enter Customer Important Informations");
        String customer_otherinfor=sc.nextLine();
        System.out.println("Enter Customer Age");
        int customer_age=sc.nextInt();
        System.out.println("Enter Amount Paid By Customer Per Apartment");
        Payment payment=new Payment();
        payment.setamount();
        System.out.println("name of customer is "+customer_name+" from nation "+customer_natinality+" aged of "+customer_age+".customer other information is "+customer_otherinfor);
    }
}