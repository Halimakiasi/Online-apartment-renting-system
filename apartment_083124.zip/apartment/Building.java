public class Building {
    private String building_name;
    private String street;
    public Building() {}
    public Building(String building_name,String street) {
        this.building_name="AMANI HOUSE";
        this.street="KWA WAZEE";
    }
    public void setbuildingname() {
        this.building_name=building_name;
    }
    public String getbuildingname() {
        return building_name;
    }
    public void setstreet() {
        this.street=street;
    }
    public String getstreet() {
        return street;
    }
}
class Apartment extends Building {
    private String apartment_name;
    private int apartment_number;
    public Apartment(String building_name,String street) {
        super(building_name,street);
        this.apartment_name="SAFARI";
        this.apartment_number=123;
    }
    public Apartment(String building_name,String street,String apartment_name) {
        super(building_name,street);
        this.apartment_name=apartment_name;
    }
    public Apartment(String building_name,String street,String apartment_name,int apartment_number) {
        super(building_name,street);
        this.apartment_name=apartment_name;
        this.apartment_number=apartment_number;
    }
    public void setapartmentname() {
        this.apartment_name=apartment_name;
    }
    public String getapartmentname() {
        return apartment_name;
    }
    public void setapartmentnumber() {
        this.apartment_number=apartment_number;
    }
    public int getapartment() {
        return apartment_number;
    }
    public String tostring() {
        String x="apartment name and number are "+apartment_name+" and "+apartment_number;
        return x;
    }
}
class InheritanceApartment {
    public static void main(String[] args) {
        Apartment apartment=new Apartment("AMANI HOUSE","KWA WAZEE","SAFARI",123);
        System.out.println("building name is "+apartment.getbuildingname());
        System.out.println("building found in "+apartment.getstreet());
        System.out.println("building name is "+apartment.tostring());
    }
}