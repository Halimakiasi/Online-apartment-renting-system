class Report {
    protected String type="apartment are available at any time please contact number 0777 456 098 or 0776 7869 5647";
}
class Information extends Report {
    public  String type="for more detail you can meet our customer care office at MKWAJUNGOMA BRANCH";
    public void printType() {
        System.out.println("READ HERE "+type);
        System.out.println("READ HERE "+type);
    }
}
class Main {
    public static void main(String[] args) {
        Information job=new Information();
        job.printType();
    }
}