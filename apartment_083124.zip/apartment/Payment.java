class Payment {
    private double amount=15000000.00;
    public void setamount() {
        System.out.println("amount paid for rent is "+amount);
    }
}    